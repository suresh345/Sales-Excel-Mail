﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using ClosedXML.Excel;
using DocumentFormat.OpenXml;
using System.Net.Mail;
using System.Data.Odbc;

namespace EmailAutoYear
{
    public partial class Service1 : ServiceBase
    {
        string strLogPath = ConfigurationSettings.AppSettings["LogPath"];
        Timer _timer = new Timer();
        string strLog = "";
        string strQry = "";
        
         

        private string strUnSucessPath;
        private string strfname;
        private string path;
        private readonly string dt1;

        public Service1()
        {
            InitializeComponent();
            _timer.Interval = Convert.ToDouble(ConfigurationSettings.AppSettings["TimerInterval"].ToString());

            //enabling the timer
            _timer.Enabled = true;

            //handle Elapsed event
            _timer.Elapsed += new ElapsedEventHandler(_timer_Elapsed);
 
        }

        private void _timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _timer.Stop();

            try
            {
                string TimerDuration = ConfigurationSettings.AppSettings["TimerDuration"].ToString();
                string strCurrnetTime = System.DateTime.Now.Hour.ToString() + ":" + System.DateTime.Now.Minute.ToString();


                if (TimerDuration.Split(',').Contains(strCurrnetTime))
                {
                    strLog = DateTime.Now.ToString("hh:mm:ss tt") + "Hittttttted Time taken service " + strCurrnetTime;
                    if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                        using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                    else
                        using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                    ExceltoMail(); 
                }
                else
                {
                    strLog = DateTime.Now.ToString("hh:mm:ss tt") + " Time not Hitting service " + strCurrnetTime;
                    if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                        using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                    else
                        using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                _timer.Start();
            }
        }
         
        


        public void ExceltoMail()
        {
            // call Siva SP to get dt1


            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();

            string strQry = "", strQry1= "";
            strQry = "select format(cast(issue_date as date), 'dd/MM/yyyy') as issue_date,adv_no,booking_no,actual_page_no,[AD TYPE],adv_height,adv_width,Agency_Name,Client_Name,replace(Edition_Name,'HINDU TAMIL','') as Edition_Name, NetAmt,ADS_STATUS,ALL_STATUS from VIEW_AGENCY_WISE_REPORT where issue_date between '2019-04-01' and  CONVERT(date,getdate()) and  ALL_STATUS in ('UN BILLED','BOOKED') ";
             
            strQry1 = "select format(cast(issue_date as date), 'dd/MM/yyyy') as issue_date,adv_no,booking_no,actual_page_no,[AD TYPE],adv_height,adv_width,Agency_Name,Client_Name,replace(Edition_Name,'HINDU TAMIL','') as Edition_Name, NetAmt,ADS_STATUS,[PAYMENT STATUS] from VIEW_AGENCY_WISE_REPORT where issue_date between '2019-04-01' and CONVERT(date,getdate()) and  [payment status]='1.NOT MOVED TO PROD'";
            dt = ReturndatatableSQL(strQry);dt1 = ReturndatatableSQL1(strQry1);
            string filename = converttoexcel(dt, dt1);

            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");
                mail.From = new MailAddress("notify@thehindutamil.co.in", "The Hindu Tamil");

                mail.To.Add("commercial@thehindutamil.co.in");
                mail.CC.Add("mahesh.m@thehindutamil.co.in");
               
                 mail.CC.Add("venkatakrishnan.ks@thehindutamil.co.in");

                  mail.Subject = "Unbilled Ads and Not Moved Production till date";
                mail.Body = "Please find attached the details of UnBilled Ads till date. Please take necessary action." + "This is a system generated mail and please do not reply to this mail. ";

                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment(path);
                mail.Attachments.Add(attachment);

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("notify@thehindutamil.co.in", "Vjjgh+zJQnxCPzwg=pfuKQkoePPVbgUSgeCdDX59M18t");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
            }
            catch (Exception ex5)
            {

            }
        }

        private string converttoexcel(DataTable dt, DataTable dt1)
        {
            XLWorkbook wb = new XLWorkbook();
            var ws1 = wb.Worksheets.Add(dt, "Sheet1");
            ws1.Name = "Unbillied Details";
            if (dt1 != null) // not sure if this check is needed, remove it and check if it works correctly
            {
                var ws2 = wb.Worksheets.Add(dt1, "Sheet2");
                ws2.Name = "Not Moved Production";
            }

            strfname = "Ubilled Ads & Not Moved Production" + " " + DateTime.Now.ToString().RemoveSpecialCharacters();
            path = @"D:\\UnbilledDetailsLog\\EXCEL\" + strfname + ".xlsx";
            wb.SaveAs(path);
            return strfname;
        }

        private DataTable ReturndatatableSQL(string strQry)
        {
            DataTable dt = new DataTable();
          

            try
            {
                string _strConstr = ConfigurationSettings.AppSettings["ConStr"].ToString();

                try
                {
                    using (SqlConnection conn = new SqlConnection(_strConstr))
                    {
                        try
                        {
                            conn.Open();
                            
                            SqlDataAdapter da = new SqlDataAdapter(strQry, conn);  
                            da.Fill(dt); conn.Close();
                        }
                        catch (SqlException ex)
                        { if (conn.State == ConnectionState.Open) conn.Close(); }
                    }
                }
                catch (Exception ex) { }

            }
            catch (Exception ex1) { }
            return dt;
        }
        private DataTable ReturndatatableSQL1(string strQry1)
        {
             
            DataTable dt1 = new DataTable();

            try
            {
                string _strConstr = ConfigurationSettings.AppSettings["ConStr"].ToString();

                try
                {
                    using (SqlConnection conn = new SqlConnection(_strConstr))
                    {
                        try
                        {
                            conn.Open();
                         SqlDataAdapter da = new SqlDataAdapter(strQry1, conn);
                           da.Fill(dt1); conn.Close();
                        }
                        catch (SqlException ex)
                        { if (conn.State == ConnectionState.Open) conn.Close(); }
                    }
                }
                catch (Exception ex) { }

            }
            catch (Exception ex1) { }
            return dt1;
        }
        protected override void OnStart(string[] args)
        {
            _timer.Start();
            strLogPath = ConfigurationSettings.AppSettings["LogPath"].ToString();

            if (!Directory.Exists(strLogPath))
                Directory.CreateDirectory(strLogPath);

            if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Emailsend_LOG.txt"))
                using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Emailsend_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + " _Emailsend_LOG  Service Started ....");
            else
                using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_EmailsendNot_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + " _EmailsendNot_LOG  Service Started ....");
        }

        protected override void OnStop()
        {
            _timer.Stop();

            if (!Directory.Exists(strLogPath))
                Directory.CreateDirectory(strLogPath);

            if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_EmailsendNot_LOG.txt"))
                using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_EmailsendNot_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + " _EmailsendNot_LOG  Service Stoped ....");
            else
                using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_EmailsendNot_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + "_EmailsendNot_LOG  Service Stoped ....");
        }
        


    }
}
